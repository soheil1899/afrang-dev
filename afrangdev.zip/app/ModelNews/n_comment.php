<?php

namespace App\ModelNews;

use Illuminate\Database\Eloquent\Model;

class n_comment extends Model
{
    //
}
