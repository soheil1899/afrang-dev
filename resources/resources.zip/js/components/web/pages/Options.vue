<template>
    <div dir="ltr" class="padding150 row shadow-sm px-5 mx-0">

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-shopping-cart fa-3x mb-4"></i>
                <h5><strong>
                    Online Store
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-satellite-dish fa-3x mb-4"></i>
                <h5><strong>
                    News
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-home fa-3x mb-4"></i>
                <h5><strong>
                    Real Estate Advisor
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-stethoscope fa-3x mb-4"></i>
                <h5><strong>
                    Reservation of medical services
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-hotel fa-3x mb-4"></i>
                <h5><strong>
                    Hotel
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-microscope fa-3x mb-4"></i>
                <h5><strong>
                    Scientific & Educational
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-ad fa-3x mb-4"></i>
                <h5><strong>
                    Online Advertising
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-plane fa-3x mb-4"></i>
                <h5><strong>
                    Travel Agency
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-chalkboard-teacher fa-3x mb-4"></i>
                <h5><strong>
                    Educational Institution
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-palette fa-3x mb-4"></i>
                <h5><strong>
                    Decoration Company
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-hospital fa-3x mb-4"></i>
                <h5><strong>
                    Hospital
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-utensils fa-3x mb-4"></i>
                <h5><strong>
                    Online Food Ordering
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-ship fa-3x mb-4"></i>
                <h5><strong>
                    Business & Trading
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-cog fa-3x mb-4"></i>
                <h5><strong>
                    Manufacturer
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fab fa-itunes-note fa-3x mb-4"></i>
                <h5><strong>
                    Cultural & Artistic
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-book fa-3x mb-4"></i>
                <h5><strong>
                    Book Publishing
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-cut fa-3x mb-4"></i>
                <h5><strong>
                    Makeup & Trimming
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-torii-gate fa-3x mb-4"></i>
                <h5><strong>
                    Tourism
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-running fa-3x mb-4"></i>
                <h5><strong>
                    Sport Club
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="far fa-comments fa-3x mb-4"></i>
                <h5><strong>
                    Social Networks
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="far fa-play-circle fa-3x mb-4"></i>
                <h5><strong>
                    Multimedia
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-camera-retro fa-3x mb-4"></i>
                <h5><strong>
                    Photo Studio
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-download fa-3x mb-4"></i>
                <h5><strong>
                    Download
                </strong></h5>
            </div>
        </div>

        <div class="col-6 col-md-4 col-lg-2 text-center p-2">
            <div class="shadow-sm pointer work-option p-3">
                <i class="fas fa-briefcase fa-3x mb-4"></i>
                <h5><strong>
                    Recruitment
                </strong></h5>
            </div>
        </div>


    </div>
</template>

<script>
    export default {
        name: "Options"
    }
</script>

<style scoped>

</style>