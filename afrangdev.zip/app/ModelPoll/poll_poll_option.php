<?php

namespace App\ModelPoll;

use Illuminate\Database\Eloquent\Model;

class poll_poll_option extends Model
{
    //
}
