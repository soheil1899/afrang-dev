@extends('admin.dashboard')
@section('page')
<articlelist></articlelist>

@endsection