<?php

namespace App\ModelPoll;

use Illuminate\Database\Eloquent\Model;

class poll_poll extends Model
{
    //
}
