<?php

namespace App\ModelNews;

use Illuminate\Database\Eloquent\Model;

class n_layout_adv extends Model
{
    protected  $table='n_layout_adv';
}
