<?php

namespace App\ModelNews;

use Illuminate\Database\Eloquent\Model;

class n_tags_menu extends Model
{
    //
}
