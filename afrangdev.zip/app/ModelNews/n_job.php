<?php

namespace App\ModelNews;

use Illuminate\Database\Eloquent\Model;

class n_job extends Model
{
    //
}
