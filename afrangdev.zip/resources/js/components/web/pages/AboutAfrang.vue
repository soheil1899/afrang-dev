<template>

    <div>
        <div dir="ltr" class="shadow-sm container-fluid py-5 backwhite">
            <articleshow :id="23" :flag="'aboutafrangtop'"></articleshow>

        </div>



        <articleshow :id="24" :flag="'aboutafrangbottom'"></articleshow>




    </div>



</template>

<script>
    export default {
        name: "AboutAfrang"
    }
</script>

<style scoped>

</style>