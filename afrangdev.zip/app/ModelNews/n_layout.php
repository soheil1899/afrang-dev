<?php

namespace App\ModelNews;

use Illuminate\Database\Eloquent\Model;

class n_layout extends Model
{
   protected  $table='n_layout';
}
