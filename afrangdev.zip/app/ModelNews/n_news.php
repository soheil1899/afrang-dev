<?php

namespace App\ModelNews;

use Illuminate\Database\Eloquent\Model;

class n_news extends Model
{
    //
}
