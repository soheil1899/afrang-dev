<?php

namespace App\ModelNews;

use Illuminate\Database\Eloquent\Model;

class n_adver_customer extends Model
{
    protected  $table='n_adver_customer';
}
