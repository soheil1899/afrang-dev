@extends('website.layouts.main')
@section('css')
    <link rel="stylesheet" type="text/css" href="{{ asset('/css/app.css') }}">
@endsection
@section('js')
    <script src="{{ asset('/js/app.js') }}"></script>
@endsection
@section('main')





    {{--    <div dir="ltr" class="position-relative shadow-sm"--}}
    {{--         style="width: 100%; height: auto; display: block; padding-bottom: 130px">--}}
    {{--        <div class="stripes-container">--}}
    {{--            <div class="stripe"></div>--}}
    {{--            <div class="stripe"></div>--}}
    {{--            <div class="stripe"></div>--}}
    {{--            <div class="stripe"></div>--}}
    {{--            <div class="stripe"></div>--}}
    {{--        </div>--}}


    {{--        <h1 class="text-center pt-5" style="text-shadow: 0 0 2px">--}}
    {{--            <strong>--}}
    {{--                Create Your Own Business--}}
    {{--            </strong>--}}
    {{--        </h1>--}}
    {{--        <h3 class="text-center pb-4" style="text-shadow: 0 0 2px; color: #0a9234">--}}
    {{--            <i>--}}
    {{--                <strong>--}}
    {{--                    Special Offer for Summer--}}
    {{--                </strong>--}}
    {{--            </i>--}}
    {{--        </h3>--}}


    {{--        <img src="/media/test-folder/banner.png" width="60%" class="d-block mx-auto">--}}


    {{--    </div>--}}


    <firstpage></firstpage>






@endsection
