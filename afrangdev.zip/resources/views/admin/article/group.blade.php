@extends('admin.dashboard')
@section('page')
<div>
  <grouplist></grouplist>
</div>
@endsection
