<?php
/**
 * Created by PhpStorm.
 * User: Afrang
 * Date: 2/5/2019
 * Time: 12:02 AM
 */

namespace App;
use Illuminate\Database\Eloquent\Model;


class languagelist extends  Model
{
    protected $table='languagelist';
    protected $primaryKey='id';

}