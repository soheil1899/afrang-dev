<?php
/**
 * Created by PhpStorm.
 * User: Afrang
 * Date: 4/3/2019
 * Time: 5:31 PM
 */
return [
    'MarketManager' => 'داشبورد ',
    'Maket Place' => 'محصولات ',
    'Profile' => 'پروفایل ',
    'New Product' => 'محصول جدید ',
    'Profile Edit' => 'ویرایش پروفایل ',
    'Market Edit' => 'ویرایش مارکت ',
    'Product Manager' => 'مدیریت محصولات',
    'This Pic is Master Picture. You Can Delete This Item.' => 'این عکس اصلی می باشد. نمی توان آن را پاک نمود',

    ];