<?php
/**
 * Created by PhpStorm.
 * User: afrang
 * Date: 1/13/19
 * Time: 12:41 AM
 */

namespace App;
use Illuminate\Database\Eloquent\Model;

class roll extends  Model
{
    protected $table='roll';
    protected $primaryKey='id';

}
