<?php

namespace App\ModelNews;

use Illuminate\Database\Eloquent\Model;

class n_score_comment extends Model
{
    //
}
