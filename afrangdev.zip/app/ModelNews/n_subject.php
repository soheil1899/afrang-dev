<?php

namespace App\ModelNews;

use Illuminate\Database\Eloquent\Model;

class n_subject extends Model
{
    protected $table='n_subject';
}
